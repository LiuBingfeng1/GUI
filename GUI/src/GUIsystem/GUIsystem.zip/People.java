package GUIsystem;

public class People {
	String id;
	String name;
	String sex;
	public People(String id,String name,String sex) {
		this.id=id;
		this.name=name;
		this.sex=sex;
	}
}