package GUIsystem;
public class SystemTest {
	public String[] getSubjects() {
		Teacher teaone=new Teacher("001","张老师","F","Java");
		Teacher teatwo=new Teacher("002","游老师","F","Math");
		Teacher teathree=new Teacher("003","李老师","F","Physics");
		Teacher teafour=new Teacher("004","于老师","M","PE");
		Teacher teafive=new Teacher("005","常老师","M","English");
		Subject subone=new Subject("1","Java","houseone","8:00",teaone);
		Subject subtwo=new Subject("2","Math","housetwo","9:00",teatwo);
		Subject subthree=new Subject("3","Physics","housethree","10:00",teathree);
		Subject subfour=new Subject("4","PE","housefour","11:00",teafour);
		Subject subfive=new Subject("5","English","housefive","12:00",teafive);
		String [] subjects= {subone.toString(),subtwo.toString(),subthree.toString(),subfour.toString(),subfive.toString()};
		return subjects;
		}
}